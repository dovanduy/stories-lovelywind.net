<?php 
	include('include_cat/header.php');
	include('include_cat/top.php');
	include('include_cat/center.php');
	include('include_cat/footer.php');
?>