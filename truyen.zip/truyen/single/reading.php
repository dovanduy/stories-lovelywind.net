<?php 
	include('include_single/header.php');
	include('include_single/top_reading.php');
	include('include_single/center_reading.php');
	include('include_single/footer.php');
?>