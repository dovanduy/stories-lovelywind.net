<?php 
	include('include_single/header.php');
	include('include_single/top.php');
	include('include_single/center.php');
	include('include_single/footer.php');
?>