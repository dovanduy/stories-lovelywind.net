﻿<?php 
	include('homepage/header.php');
	include('homepage/top.php');
	include('homepage/center.php');
	include('homepage/footer.php');	
?>