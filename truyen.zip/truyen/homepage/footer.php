</div>
<div id="footer">
            
            <div class="logo-footer">
                <img src="images/LovelyNew2.png"/>
                <p style="color:#CCC"><?php echo SL_footer; ?></p>
            </div>
            
            <div class="single-footer-1">
                <span>Liên hệ với chúng tôi</span>
                <div class="soc-i">
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-youtube"></i>
                    <i class="fas fa-envelope"></i>
                </div>
            </div>
            
            <div class="single-footer-2">
                <span style="font-size:16px;">Quy định</span>
                <ul>
                    <li>Điều khoản sử dụng</li>
                    <li>Chính sách riêng tư</li>
                    <li>Khiếu nại bản quyền</li>
                </ul>
            </div>  
                   
            <div class="single-footer-2">
                <span style="font-size:16px;">Hợp tác</span>
                <ul>
                    <li>Hợp tác nội dung</li>
                    <li>Hướng dẫn sử dụng</li>
                    <li>Liên hệ quảng cáo</li>
                </ul>
            </div>
            
            
            <div class="clear"></div>
        </div>
          

</body>
</html>