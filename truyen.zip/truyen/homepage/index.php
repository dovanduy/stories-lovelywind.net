<?php
	include('../include/function.php');
	redirect_to('../','','');
?>