<?php 

    $title = "";
    echo strip_tags(trim(substr($title,strpos($title,":")+1)));
?>